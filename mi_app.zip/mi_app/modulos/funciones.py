def sumar(a, b):
    return a + b

def es_par(numero):
    return numero % 2 == 0
